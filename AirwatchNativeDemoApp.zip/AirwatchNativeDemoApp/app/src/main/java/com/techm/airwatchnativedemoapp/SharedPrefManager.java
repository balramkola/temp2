package com.techm.airwatchnativedemoapp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Calendar;
import java.util.Date;

public class SharedPrefManager {

    private static SharedPrefManager mInstance;
    private static Context mCtx;

    private SharedPrefManager(Context context) {
        mCtx = context;
    }

    public static synchronized SharedPrefManager getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new SharedPrefManager(context);
        }
        return mInstance;
    }

    //save sessionId
    public void saveSessionId(String sessionId) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences("LPSharedPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Calendar now = Calendar.getInstance();
        Date date = new Date(System.currentTimeMillis());
        editor.putString("sessionId", sessionId);
        editor.putLong("sessionTimer",now.getTimeInMillis());
        editor.apply();
    }


}