//package com.aramco.logisticstestaw;
package com.techm.airwatchnativedemoapp;

import android.content.Intent;
import android.content.pm.PackageManager;
import androidx.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import com.airwatch.app.AWApplication;
import com.airwatch.gateway.ui.GatewaySplashActivity;
//import com.airwatch.login.ui.activity.SDKSplashActivity;
//import com.aramco.logisticstestaw.activities.MainActivity;

import java.security.cert.X509Certificate;

public class AirWatchSDKSampleApp extends AWApplication {

    private String TAG = AirWatchSDKSampleApp.class.getSimpleName();

    @Override
    public Intent getMainActivityIntent() {
        PackageManager pm = getPackageManager();
        //Intent intent=pm.getLaunchIntentForPackage("com.ahmed.ionic.airwatchsdk");
//        startActivity(intent);
//        Toast.makeText(getApplicationContext(),"get main Actvity",Toast.LENGTH_LONG).show();
        //return intent;
//        Log.w(TAG, " :: get main activity intent");
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        return intent;
    }

    @Override
    public Intent getMainLauncherIntent() {
        Log.w(TAG, " :: get GatewaySplashActivity intent");
        return new Intent(getApplicationContext(), GatewaySplashActivity.class);
    }

    @Override
    public void onPostCreate() {
        Log.w(TAG, " :: onPostCreate");
        super.onPostCreate();
    }

    @Override
    public void onSSLPinningValidationFailure(String s, @Nullable X509Certificate x509Certificate) {
        Log.w(TAG, " :: onSSLPinningValidationFailure");
    }

    @Override
    public void onSSLPinningRequestFailure(String s, @Nullable X509Certificate x509Certificate) {
        Log.w(TAG, " :: onSSLPinningRequestFailure");
    }

    @Override
    public boolean getMagCertificateEnable() {
        Log.w(TAG, " :: getMagCertificateEnable");
        return true;
    }

    @Override
    public boolean getIsStandAloneAllowed() {
        Log.w(TAG, " :: getIsStandAloneAllowed");
        return true;
    }
}


