package com.techm.airwatchnativedemoapp;

import android.content.Context;
import android.util.Base64;
import android.util.Log;

import com.airwatch.sdk.AirWatchSDKException;
import com.airwatch.sdk.SDKManager;
import com.airwatch.sdk.context.SDKContextManager;
import com.android.volley.AuthFailureError;
import com.android.volley.Header;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.net.CookieHandler;
import java.net.CookieManager;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class AirwatchHandler {

    private static final String TAG = "PLUGIN: " + AirwatchHandler.class.getSimpleName();
    private Context appContext;
    private ResponseHandlerInterface callback;

    public AirwatchHandler(Context appContext, ResponseHandlerInterface callback) {
        this.appContext = appContext;
        this.callback = callback;
    }

    public static CookieManager cookieManager;

    private SDKManager awSDKManager = null;

    public void init() {
        
        if (cookieManager == null) {
            cookieManager = new CookieManager();
            CookieHandler.setDefault(cookieManager);
        }
        NukeSSLCerts();
        new Thread(new Runnable() {
            public void run() {
                try {
                    Log.w(TAG, "Initializing Airwatch SDK ");
                    awSDKManager = SDKManager.init(appContext);
                    Initialize();
                    Log.w(TAG, "awSDKManager :: is initialized ! ");
                    callback.handleResult("awSDKManager :: is initialized ! ");
                } catch (AirWatchSDKException e) {
                    Log.e(TAG, "Error in init :: " + e.getMessage());
//                    runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            String reason = "AirWatch SDK Connection Problem. " + "Please make sure AirWatch Agent is Installed ";
//                            Toast.makeText(getApplicationContext(), reason, Toast.LENGTH_SHORT).show();
//                        }
//                    });
                    callback.handleResult("Error in initializing AirWatch: " + e.getMessage());
                }
            }
        }).start();
    }

    private void Initialize() {
        try {
            if (awSDKManager.hasAPIPermission()) {
                switch (SDKContextManager.getSDKContext().getCurrentState()) {
                    case IDLE:
                        SDKContextManager.getSDKContext().initAndConfigure(appContext);
                        Log.w(TAG, "STATE :: IDLE");
                        callback.handleResult("STATE :: IDLE");
                        break;
                    case CONFIGURED:
                        Log.w(TAG, "STATE :: CONFIGURED");
                        callback.handleResult("STATE :: CONFIGURED");
                        break;
                    case INITIALIZED:
                        SDKContextManager.getSDKContext().configure();
                        Log.w(TAG, "STATE :: INITIALIZED");
                        callback.handleResult("STATE :: INITIALIZED");
                        break;
                }
            } else {
                Log.e(TAG, "App is not whitelisted with AirWatch backend");
                callback.handleResult("App is not whitelisted with AirWatch backend");
            }
        } catch (Exception e) {
            Log.e(TAG, "SDKManager does not have API permission", e);
            callback.handleResult("SDKManager does not have API permission: " + e);
        }
    }

    //This method will trust all certficates *** ONLY FOR TESTING ***
    public void NukeSSLCerts() {
        Log.w(TAG, "Trusting all certificates");
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        public X509Certificate[] getAcceptedIssuers() {
                            return new X509Certificate[0];
                        }

                        @Override
                        public void checkClientTrusted(X509Certificate[] certs, String authType) {
                        }

                        @Override
                        public void checkServerTrusted(X509Certificate[] certs, String authType) {
                        }
                    }
            };
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String arg0, SSLSession arg1) {
                    return true;
                }
            });
            callback.handleResult("certificates nuked");
        } catch (Exception e) {
            Log.e(TAG, " Error in NukeSSLCerts :: " + e.getMessage());
            callback.handleResult(" Error in NukeSSLCerts :: " + e.getMessage());
        }
    }

    public void getService(String url) {
        Log.w(TAG, "Calling Method loginService for Url: " + url);
        RequestQueue queue = Volley.newRequestQueue(appContext);
        //check internet availability
        if (NetworkAvalability.isNetworkConnected(appContext)) {

            //if everything is fine call server
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.d("Response", "" + response);
                            //resultTextView.setText(response.toString());
                            callback.handleResult(response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Log.e(TAG, "Error on Response \n" + error.getMessage());

                            try {
                                //get status code
                                int errorCode = error.networkResponse.statusCode;
                                Log.e(TAG, "Response Code : " + errorCode);

                                String message = error.getMessage();
                                //resultTextView.setText("" + message);
                                callback.handleResult(message);

                            } catch (Exception e) {
                                //resultTextView.setText("" + error.getMessage());
                                Log.e(TAG, "Error EXC :: " + e.getMessage());
                                callback.handleResult("Error EXC :: " + e.getMessage());
                            }
                        }
                    }) {

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    //TODO Store session ID in shared preferences

                    Log.w(TAG, "  ::   RESPONSE CODE :::   " + response.statusCode);
                    Log.w(TAG, "  ::   RESPONSE HEADERS  :: ");
                    List<Header> lh = response.allHeaders;
                    for (int i = 0; i < lh.size(); i++) {
                        Log.w(TAG, lh.get(i).getName() + " : " + lh.get(i).getValue());
                    }
                    return super.parseNetworkResponse(response);
                }
            };
            queue.add(stringRequest);
        } else {
            //if No internet
            //resultTextView.setText("" + "No Internet Connection !");
            callback.handleResult("No Internet Connection !");
        }

    }

    public void loginService(String url, final String username, final String password) {

        Log.w(TAG, "Calling Method loginService for Url: " + url);

        //  final String username = unameEditText.getText().toString();
        // final String password = pwdEditText.getText().toString();

//        final String username = "THEUSER";
//        final String password = "KaustHackathon1234!";

        RequestQueue queue = Volley.newRequestQueue(appContext);
        //check internet availability
        if (NetworkAvalability.isNetworkConnected(appContext)) {

            //if everything is fine call server
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.d("Response", "" + response);
                            //resultTextView.setText(response.toString());
                            callback.handleResult(response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.e(TAG, "Error on Response \n" + error.getMessage());

                            try {
                                //get status code
                                int errorCode = error.networkResponse.statusCode;
                                Log.e(TAG, "Response Code : " + errorCode);
                                String message = error.getMessage();
                                //resultTextView.setText("" + message);
                                callback.handleResult(message);
                            } catch (Exception e) {
                                //resultTextView.setText("" + error.getMessage());
                                callback.handleResult(error.getMessage());
                                Log.e(TAG, e.getMessage());
                            }
                        }
                    }) {

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    //sending credentials to server
                    String credentials = username + ":" + password;
                    String base64EncodedCredentials = Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
                    HashMap<String, String> headers = new HashMap<>();
                    headers.put("Authorization", "Basic " + base64EncodedCredentials);
                    return headers;
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    //TODO Store session ID in shared preferences
                    Log.w(TAG, "  ::   RESPONSE CODE :::   " + response.statusCode);
                    Log.w(TAG, "  ::   RESPONSE HEADERS  :: ");
                    List<Header> lh = response.allHeaders;
                    for (int i = 0; i < lh.size(); i++) {
                        Log.w(TAG, lh.get(i).getName() + " : " + lh.get(i).getValue());
                    }
                    String sessionId = response.headers.get("Set-Cookie");
                    SharedPrefManager.getInstance(appContext).saveSessionId(sessionId);
                    callback.handleResult("got cookie from server");
                    return super.parseNetworkResponse(response);
                }
            };
            queue.add(stringRequest);
        } else {
            //if No internet
            callback.handleResult("No Internet Connection !");
            //resultTextView.setText("" + "No Internet Connection !");
        }
    }

    interface ResponseHandlerInterface {
        void handleResult(String result);
    }
}
