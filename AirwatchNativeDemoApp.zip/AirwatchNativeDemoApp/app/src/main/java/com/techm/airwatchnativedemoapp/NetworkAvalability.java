package com.techm.airwatchnativedemoapp;



import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;


public class NetworkAvalability {

    public enum NetworkStatus {
        WIFI,
        MOBILE,
        UNREACHABLE
    }

    private static NetworkAvalability instance;

    private NetworkAvalability() {
    }

    public static NetworkAvalability getInstance(){
        if(instance == null){
            instance = new NetworkAvalability();
        }
        return instance;
    }

    private class NetworkRequestCallback extends ConnectivityManager.NetworkCallback {
        @Override
        public void onAvailable(Network network) {
            super.onAvailable(network);
        }

        @Override
        public void onLost(Network network) {
            super.onLost(network);
        }

        @Override
        public void onUnavailable() {
            super.onUnavailable();
        }
    }

    public static String getWifiName(Context context) {

        WifiManager wifiManager = (WifiManager)context.getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifiManager.getConnectionInfo ();
        return info.getSSID();
    }

    public static boolean isNetworkConnected(Context context) {
        ConnectivityManager connMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = connMgr.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnected();
    }

    public static NetworkStatus isWifiOrMobileConnected(Context context) {

        ConnectivityManager connMgr = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        boolean isWifiConn = false;
        boolean isMobileConn = false;
        for (Network network : connMgr.getAllNetworks()) {

            NetworkInfo networkInfo = connMgr.getNetworkInfo(network);

            if (Build.VERSION.SDK_INT > 27) {

                NetworkCapabilities capabilities = connMgr.getNetworkCapabilities(network);
                if (capabilities != null) {
                    if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        isWifiConn |= networkInfo.isConnected();
                    } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                        isMobileConn |= networkInfo.isConnected();
                    }
                }
            }
            else {

                if (networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                    isWifiConn |= networkInfo.isConnected();
                }
                if (networkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
                    isMobileConn |= networkInfo.isConnected();
                }
            }

        }


        return (isWifiConn? NetworkStatus.WIFI : isMobileConn? NetworkStatus.MOBILE : NetworkStatus.UNREACHABLE);
    }

//    public boolean isInternetAvailable() {
//
//        boolean reachable = false;
//
//        try {
//            // Address can be hostName, IPV4 or IPV6: http://java.sun.com/javase/6/docs/api/java/net/InetAddress.html#getByName%28java.lang.String%29
//            reachable = new InternetAvailable().execute().get();
//
//        } catch (Exception e) {
//        }
//
//        return reachable;
//    }
//
//    private class InternetAvailable extends AsyncTask<Void, Void, Boolean> {
//
//        @Override
//        protected Boolean doInBackground(Void... voids) {
//            try {
//                InetAddress ipAddr = InetAddress.getByName("google.com");
//                return !ipAddr.equals("");
//
//            } catch (Exception e) {
//                return false;
//            }
//        }
//    }
}
